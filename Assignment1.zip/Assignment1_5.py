def main():
    num = 10
    while(num>0):
        print(num)
        num = num - 1


if __name__ == "__main__":
    main()