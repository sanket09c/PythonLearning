def printStars(no):
    i = 0
    print("Output: ")
    for i in range(no):

        print(" *")
        i = i+1

def main():
    print("Enter the number: ")
    num = int(input())
    printStars(num)


if __name__ == "__main__":
    main()    