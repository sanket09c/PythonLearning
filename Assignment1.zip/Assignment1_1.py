def Fun():
    print("hello from fun")



def main ():
    Fun()


if __name__ == "__main__":
    main()
