def printEven(no):
    i = 0
    print("Output: ")
    while (i <= no*2):
        print(i)
        i = i+2


def main():
    print("Enter the number of even nos to be displayed: ")
    num = int(input())
    printEven(num)


if __name__ == "__main__":
    main()    