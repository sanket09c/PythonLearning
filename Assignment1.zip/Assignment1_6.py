def checkStatus(no):
    if (no > 0):
        print("number is positive")
    elif (no < 0):
        print("number is negative")
    else:
        print("Number is equal to zero")


def main():
    print("Enter the number: ")
    num = int(input())
    checkStatus(num)


if __name__ == "__main__":
    main()    