def Add(no1, no2):
    ans = 0
    ans  = no1 + no2
    return ans

def Mul(no1, no2):
    ans = 0
    ans  = no1 * no2
    return ans

def Sub(no1, no2):
    ans = 0
    ans  = no1 - no2
    return ans

def Div(no1, no2):
    ans = 0
    ans  = no1 / no2
    return ans