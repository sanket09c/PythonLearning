def checkStatus(no):
    if (no % 5 == 0):
        print("true")
    else:
        print("false")


def main():
    print("Enter the number: ")
    num = int(input())
    checkStatus(num)


if __name__ == "__main__":
    main()    