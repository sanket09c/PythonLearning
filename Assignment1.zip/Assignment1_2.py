def ChkNum(num):
    if num % 2 == 0:
        print("Number is even")
    else:
        print("Number is odd")    


def main():
    print("Enter a num: ")
    no = int(input())
    ChkNum(no)   


if __name__ == "__main__":
    main()

