def main():

    num = 5
    for no in range(5):
        print("Marvellous")

if __name__ == "__main__":
    main()