def displayLength(word):
     length = len(word)
     print(length)

def main():
    print("Enter the name: ")
    name = input()
    displayLength(name)

if __name__ == "__main__":
    main()    