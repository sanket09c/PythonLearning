def Add(no1, no2):
    addn = no1 + no2
    return addn



def main():
    print("Enter number 1: ")
    num1 = int(input())
    
    print("Enter number 2: ")
    num2 = int(input())

    sum = Add(num1, num2)
    print("Sum of two num is ", sum)



if __name__ == "__main__":
    main()